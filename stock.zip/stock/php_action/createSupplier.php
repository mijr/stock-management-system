<?php 	

require_once 'core.php';

if(isset($_POST['action'])){
	$name=$_POST['supplier_name'];
	$mobile=$_POST['mobile'];
	$address=$_POST['address'];

	$sql="insert into supplier(name,mobile,address)
	values('$name','$mobile','$address')";

	$result=mysqli_query($connect,$sql);
	if($result){
		//echo"data inserted successfully";
		
		header('location: http://localhost/stock/supplier.php');	
	}else{
		die(mysqli_error($connect));
	}
	
}// /if $_POST 
