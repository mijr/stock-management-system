<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {
	$supplierId = $_POST['supplierId'];
	$name 		= $_POST['editsupplierName']; 
  $mobile 			= $_POST['editmobile'];
  $address 					= $_POST['editaddress'];
  
 

				
	$sql = "UPDATE suppliers SET supplier_name = '$name', mobile_id = '$mobileName', address_id = '$addressName', status = '$status',  active = '$supplierStatus', status = 1 WHERE supplier_id = $supplierId ";

	if($connect->query($sql) === TRUE) {
		$valid['success'] = true;
		$valid['messages'] = "Successfully Update";	
	} else {
		$valid['success'] = false;
		$valid['messages'] = "Error while updating product info";
	}

} // /$_POST
	 
$connect->close();

echo json_encode($valid);