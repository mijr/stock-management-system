<?php 
require_once 'php_action/db_connect.php'; 
?>
<!-- bootstrap -->
<link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css">
	<!-- font awesome -->
	<link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css">

  <!-- custom css -->
  <link rel="stylesheet" href="custom/css/custom.css">

	<!-- DataTables -->
  <link rel="stylesheet" href="assests/plugins/datatables/jquery.dataTables.min.css">

  <!-- file input -->
  <link rel="stylesheet" href="assests/plugins/fileinput/css/fileinput.min.css">

  <!-- jquery -->
	<script src="assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>

  <!-- bootstrap js -->
	<script src="assests/bootstrap/js/bootstrap.min.js"></script>

<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>		
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css" />
<script src="custom/js/supplier.js"></script>
<script src="custom/js/.js"></script>
<div class="container">		
		
	<?php include("includes/header.php"); ?> 
	<div class="row">
	<div class="col-md-12">

		<ol class="breadcrumb">
		  <li><a href="dashboard.php">Home</a></li>		  
		  <li class="active">Supplier</li>
		</ol>

		<div class="panel panel-default">
			<div class="panel-heading">
				<div class="page-heading"> <i class="glyphicon glyphicon-edit"></i> Manage Supplier</div>
			</div> <!-- /panel-heading -->
			<div class="panel-body">

				<div class="remove-messages"></div>

				<div class="div-action pull pull-right" style="padding-bottom:20px;">
					<button class="btn btn-default button1"type="button" supplierName="add" id="addSupplier" data-toggle="modal" data-target="#addSupplierModel"> <i class="glyphicon glyphicon-plus-sign"></i> Add Supplier </button>
				</div> <!-- /div-action -->  
				<label for="">
					Show
					<select name="manageSuppliertable_length" id="manageSupplierTable">10
						
					</select>
					entries
				</label><br>
				
							<table class="table" id="manageSupplierTable">
  <thead>
    <tr>
	
      <th >Supplier Name</th>
      <th >Mobile</th>
      <th >Address</th>
	  <th ></th>`
	  <th >Option</th>
    </tr>
  </thead>
  <tbody>
  <?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "stock");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt select query execution
$sql = "SELECT * FROM supplier";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        
           
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['mobile'] . "</td>";
                echo "<td>" . $row['address'] . "</td>";
				echo "<td>";
                echo '<td><b><font color="#663300"><a href="php_action/edit.php?id=' . $row['id'] . '">Edit</a></font></b></td>';
                echo '<td><b><font color="#8B0000"><a href="php_action/delete.php?id=' . $row['id'] . '">Delete</a></font></b></td>';
                echo "</td>";
				
            echo "</tr>";
        }
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
  </tbody>
</table>
							
						</div>
					</div>
				</div>
			</div>
		</div>
        <div id="supplierModal" class="modal fade">
        	<div class="modal-dialog">
        		<form method="post" id="submitsupplierForm"action="php_action/createSupplier.php">
        			<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title"><i class="fa fa-plus"></i> Add Supplier</h4>
						</div>
						<div class="modal-body">
							<div class="form-group">
								<label>Supplier Name</label>
								<input type="text" name="supplier_name" id="supplier_name" class="form-control" required />
							</div>	
							<div class="form-group">
								<label>Mobile</label>
								<input type="text" name="mobile" id="mobile" class="form-control" required />
							</div>								
							<div class="form-group">
								<label>Address</label>
								<textarea name="address" id="address" class="form-control" rows="5" required></textarea>
							</div>
						</div>
						<div class="modal-footer">
							<input type="hidden" name="supplier_id" id="supplier_id" />
							<input type="hidden" name="btn_action" id="btn_action" />
							<input type="submit" name="action" id="action" class="btn btn-info" value="addSupplier"  />
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						</div>
					</div>
					
        		</form>
        	</div>
        </div>	
	</div>	
</div>
<!-- edit supplier -->
<div class="modal fade" id="editsupplierModel" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
    	
    	<form class="form-horizontal" id="editsupplierForm" action="php_action/editsupplier.php" method="POST">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title"><i class="fa fa-edit"></i> Edit supplier</h4>
	      </div>
	      <div class="modal-body">

	      	<div id="edit-supplier-messages"></div>

	      	<div class="modal-loading div-hide" style="width:50px; margin:auto;padding-top:50px; padding-bottom:50px;">
						<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
						<span class="sr-only">Loading...</span>
					</div>

		      <div class="edit-supplier-result">
		      	<div class="form-group">
		        	<label for="editsupplierName" class="col-sm-3 control-label">supplier Name: </label>
		        	<label class="col-sm-1 control-label">: </label>
					    <div class="col-sm-8">
					      <input type="text" class="form-control" id="editsupplierName" placeholder="supplier Name" name="editsupplierName" autocomplete="off">
					    </div>
						<label for="editsupplierName" class="col-sm-3 control-label">Mobile: </label>
		        	<label class="col-sm-1 control-label">: </label>
					    <div class="col-sm-8">
					      <input type="text" class="form-control" id="editsupplierMobile" placeholder="supplier Name" name="editmobile" autocomplete="off">
					    </div>
						<label for="editsupplierName" class="col-sm-3 control-label">Address: </label>
		        	<label class="col-sm-1 control-label">: </label>
					    <div class="col-sm-8">
					      <input type="text" class="form-control" id="editsupplierAddress" placeholder="supplier Name" name="editaddress" autocomplete="off">
					    </div>
		        </div> <!-- /form-group-->	         	        
		      </div>         	        
		      <!-- /edit supplier result -->

	      </div> <!-- /modal-body -->
	      
	      <div class="modal-footer editsupplierFooter">
	        <button type="button" class="btn btn-default" data-dismiss="modal"> <i class="glyphicon glyphicon-remove-sign"></i> Close</button>
	        
	        <button type="submit" class="btn btn-success" id="editsupplierBtn" data-loading-text="Loading..." autocomplete="off"> <i class="glyphicon glyphicon-ok-sign"></i> Save Changes</button>
	      </div>
	      <!-- /modal-footer -->
     	</form>
	     <!-- /.form -->
    </div>
    <!-- /modal-content -->
  </div>
  <!-- /modal-dailog -->
</div>
<!-- / add modal -->
<!-- /edit supplier -->

<!-- remove supplier -->
<div class="modal fade" tabindex="-1" role="dialog" id="removeMemberModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><i class="glyphicon glyphicon-trash"></i> Remove supplier</h4>
      </div>
      <div class="modal-body">
        <p>Do you really want to remove ?</p>
      </div>
      <div class="modal-footer removesupplierFooter">
        <button type="button" class="btn btn-default" data-dismiss="modal"> <i class="glyphicon glyphicon-remove-sign"></i> Close</button>
        <button type="button" class="btn btn-primary" id="removesupplierBtn" data-loading-text="Loading..."> <i class="glyphicon glyphicon-ok-sign"></i> Save changes</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- /remove supplier -->	
<script src="custom/js/supplier.js"></script>
<?php include('includes/footer.php');?>